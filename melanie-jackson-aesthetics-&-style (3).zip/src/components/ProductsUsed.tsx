import React from 'react';
import { motion } from 'motion/react';

export default function ProductsUsed() {
  const brands = [
    {
      name: 'Elaspa',
      logoUrl: 'https://cdn.phototourl.com/free/2026-06-07-26b17336-dc59-4d1b-97f3-ae1fca769330.png',
      description: 'Certified organic, medical-grade skin therapy formulations that support cellular health and promote deep, natural rejuvenation.',
      accent: 'Organic Active Skincare',
    },
    {
      name: 'The Cure',
      logoUrl: 'https://cdn.phototourl.com/free/2026-06-07-fd4a589c-9999-4438-ac2c-3a03b1000b63.webp',
      description: 'Advanced custom-blended formulations developed to target precise needs, restore vital moisture, and protect mature skin barriers.',
      accent: 'Precision Formulations',
    },
  ];

  return (
    <section className="py-20 bg-ivory/50 border-b border-warm-beige-light/40 scroll-mt-12" id="products-used">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="font-sans text-[11px] font-bold uppercase tracking-[0.25em] text-rose-dusty">Pure Formulations</div>
          <h2 className="font-serif text-3xl sm:text-4xl text-charcoal font-light">Products Used</h2>
          <p className="font-sans text-xs sm:text-sm text-charcoal/70 leading-relaxed max-w-xl mx-auto">
            We partner exclusively with exceptional brands prioritizing biocompatible active ingredients, environmental purity, and clinical-grade results.
          </p>
        </div>

        {/* Brands Logo Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {brands.map((brand, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className="group flex flex-col items-center justify-between border border-warm-beige bg-white p-8 hover:border-sage transition-all duration-300 relative text-center"
              id={`product-brand-${brand.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex flex-col items-center space-y-6 w-full">
                {/* Brand Logo Container */}
                <div className="h-28 w-full flex items-center justify-center bg-ivory/30 p-2 overflow-hidden transition-transform duration-500 group-hover:scale-[1.02]">
                  <img
                    src={brand.logoUrl}
                    alt={`${brand.name} brand logo`}
                    className="max-h-24 max-w-[200px] object-contain select-none filter contrast-[1.05]"
                    referrerPolicy="no-referrer"
                    id={`brand-logo-${idx}`}
                  />
                </div>
                
                {/* Accent Tag */}
                <span className="font-sans text-[9px] font-bold uppercase tracking-widest text-rose-dusty bg-warm-beige-light px-3 py-1 rounded-full">
                  {brand.accent}
                </span>

                {/* Brand description */}
                <p className="font-sans text-xs text-charcoal/60 leading-relaxed max-w-xs">
                  {brand.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
