import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { motion } from 'motion/react';

interface ContactProps {
  onOpenBooking: () => void;
}

export default function Contact({ onOpenBooking }: ContactProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [contactMethod, setContactMethod] = useState<'email' | 'phone'>('email');
  const [inquiryType, setInquiryType] = useState('skincare');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !message) {
      setSubmitError('All fields marked with an asterisk (Name, Email, Phone, and Goals) are required.');
      return;
    }

    setIsLoading(true);
    setSubmitError(null);

    const payload = {
      "Contact Name": name,
      "Email Address": email,
      "Phone Number": phone,
      "Preferred Contact Channel": contactMethod === 'email' ? 'Email' : 'Phone / Text',
      "Inquiry Topic": inquiryType === 'skincare' ? 'Skincare' : inquiryType === 'wardrobe' ? 'Wardrobe' : 'Full Journey',
      "Message Detail": message
    };

    try {
      const response = await fetch('https://formspree.io/f/xbdeorwd', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setIsSubmitted(true);
        setName('');
        setEmail('');
        setPhone('');
        setContactMethod('email');
        setInquiryType('skincare');
        setMessage('');
      } else {
        const errorData = await response.json();
        setSubmitError(errorData.error || 'There was a problem submitting your inquiry. Please try again.');
      }
    } catch (error) {
      setSubmitError('A connection problem occurred. Please check your network and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-20 lg:py-28 bg-warm-beige-light scroll-mt-12" id="contact">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="lg:grid lg:grid-cols-12 lg:gap-12 items-stretch">
          
          {/* Left Column: Direct Contact Details (Col: 1-5) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-5 flex flex-col justify-between text-left space-y-8"
          >
            <div className="space-y-4">
              <div className="font-sans text-xs uppercase tracking-[0.25em] text-rose-dusty font-bold">Get in Touch</div>
              <h2 className="font-serif text-3xl sm:text-4xl text-charcoal font-light">Connect with Melanie</h2>
              <p className="font-sans text-xs sm:text-sm text-charcoal/75 leading-relaxed max-w-md">
                Have specific concerns about skincare or wardrobe consultations? Send a message directly, or request a service consultation online.
              </p>
            </div>

            {/* Direct Details Card (Minimal Flat Grid Panel style) */}
            <div className="border border-warm-beige bg-white p-6 sm:p-8 space-y-5">
              <div className="flex gap-4 items-start">
                <div className="font-sans text-left">
                  <p className="text-[9px] uppercase font-bold tracking-widest text-[#a8a095]">Call / Text</p>
                  <a href="tel:+16138780900" className="text-xs sm:text-sm font-medium text-charcoal hover:text-rose-dusty transition-all">
                    (613) 878-0900
                  </a>
                </div>
              </div>

              <div className="h-[1px] bg-warm-beige-light w-full" />

              <div className="flex gap-4 items-start">
                <div className="font-sans text-left">
                  <p className="text-[9px] uppercase font-bold tracking-widest text-[#a8a095]">Email Address</p>
                  <a href="mailto:mj@melaniejacksonstyle.com" className="text-xs sm:text-sm font-medium text-charcoal hover:text-rose-dusty transition-all">
                    mj@melaniejacksonstyle.com
                  </a>
                </div>
              </div>
            </div>

            {/* Social connection & primary book cta bottom */}
            <div className="space-y-4 pt-4">
              <div className="flex gap-4 items-center">
                <button
                  onClick={onOpenBooking}
                  className="bg-sage hover:bg-sage-dark text-white px-6 py-3.5 font-sans text-[11px] font-bold tracking-widest uppercase transition-all duration-300 w-full"
                  id="contact-general-book-btn"
                >
                  Request a Service Online
                </button>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Custom Stylized Contact Form (Col: 6-12) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-12 lg:mt-0 lg:col-span-7"
            id="contact-form-col"
          >
            <div className="border border-warm-beige bg-white p-6 sm:p-10 relative overflow-hidden flex flex-col justify-between h-full">
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-5 text-left" id="contact-inquiry-form">
                  <div className="space-y-1.5">
                    <h3 className="font-serif text-lg text-charcoal font-medium">Send an Inquiry</h3>
                    <p className="font-sans text-xs text-charcoal/60 leading-relaxed">
                      Melanie reads and responds to all inquiries within 24 business hours as part of her personal dedication.
                    </p>
                  </div>

                  <div className="space-y-4 pt-1">
                    {/* Name */}
                    <div>
                      <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                        placeholder="Sarah Jenkins"
                        id="contact-input-name"
                      />
                    </div>

                    {/* Email & Phone */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                          placeholder="sarah@example.com"
                          id="contact-input-email"
                        />
                      </div>
                      <div>
                        <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                          placeholder="(613) 555-0100"
                          id="contact-input-phone"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Preferred Contact Method Selection */}
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-2">
                      Preferred Contact Method *
                    </label>
                    <div className="flex flex-col sm:flex-row gap-5 pt-1">
                      <label className="flex items-center space-x-2.5 cursor-pointer select-none font-sans text-xs text-charcoal" id="contact-pref-email-label">
                        <input
                          type="checkbox"
                          checked={contactMethod === 'email'}
                          onChange={() => setContactMethod('email')}
                          className="h-4 w-4 border-warm-beige text-charcoal focus:ring-0 focus:outline-none rounded-none accent-charcoal cursor-pointer"
                          id="contact-pref-email"
                        />
                        <span>Reach out via Email</span>
                      </label>
                      <label className="flex items-center space-x-2.5 cursor-pointer select-none font-sans text-xs text-charcoal" id="contact-pref-phone-label">
                        <input
                          type="checkbox"
                          checked={contactMethod === 'phone'}
                          onChange={() => setContactMethod('phone')}
                          className="h-4 w-4 border-warm-beige text-charcoal focus:ring-0 focus:outline-none rounded-none accent-charcoal cursor-pointer"
                          id="contact-pref-phone"
                        />
                        <span>Reach out via Phone / Text</span>
                      </label>
                    </div>
                  </div>

                  {/* Inquiry Type Radio selection */}
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-2">
                      What are you interested in exploring? *
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'skincare', label: 'Skincare' },
                        { id: 'wardrobe', label: 'Wardrobe' },
                        { id: 'both', label: 'Full Journey' },
                      ].map((type) => {
                        const isSelected = inquiryType === type.id;
                        return (
                          <button
                            type="button"
                            key={type.id}
                            onClick={() => setInquiryType(type.id)}
                            className={`py-2 px-1 border font-sans text-[10px] uppercase tracking-wider font-semibold text-center transition-all ${
                              isSelected
                                ? 'bg-sage border-sage text-white'
                                : 'bg-white border-warm-beige text-charcoal/60 hover:border-charcoal hover:text-charcoal'
                            }`}
                            id={`inquiry-radio-${type.id}`}
                          >
                            {type.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                      Brief Description of Your Goals *
                    </label>
                    <textarea
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all max-h-40 min-h-24 leading-relaxed"
                      placeholder="Please share details such as skin conditions you'd like to treat, wardrobe styles you want to explore..."
                      id="contact-input-message"
                    />
                  </div>

                  {submitError && (
                    <div className="bg-red-50 text-red-650 p-3.5 border-l-2 border-red-500 font-sans text-xs leading-normal">
                      {submitError}
                    </div>
                  )}

                  {/* Submit button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full flex items-center justify-center gap-2 bg-charcoal hover:bg-charcoal/90 text-white py-3.5 font-sans text-[11px] font-bold tracking-widest uppercase transition-all duration-300 disabled:opacity-50"
                      id="contact-form-submit-btn"
                    >
                      {isLoading ? (
                        <>Inquiring...</>
                      ) : (
                        <>
                          Send Message <Send className="h-3 w-3 text-rose-dusty" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              ) : (
                /* Success message panel state */
                <div className="h-full flex flex-col justify-center items-center text-center space-y-6 py-12 px-2">
                  <div className="space-y-2">
                    <h3 className="font-serif text-xl text-charcoal font-light">Inquiry Sent Successfully</h3>
                    <p className="font-sans text-xs text-charcoal/75 max-w-sm mx-auto leading-relaxed">
                      Thank you for reaching out. Melanie Jackson responds personally to all requests and is looking forward to connecting with you.
                    </p>
                  </div>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="border border-charcoal/10 hover:border-charcoal px-6 py-2.5 font-sans text-[10px] font-bold uppercase tracking-widest text-charcoal transition-colors duration-200"
                    id="contact-reset-form-success"
                  >
                    Send Another Message
                  </button>
                </div>
              )}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
