import React from 'react';
import { motion } from 'motion/react';

interface PhilosophyProps {
  wardrobeImageUrl?: string;
}

export default function Philosophy({ wardrobeImageUrl }: PhilosophyProps) {
  return (
    <section className="py-20 lg:py-28 bg-white overflow-hidden scroll-mt-12" id="philosophy">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
          
          {/* Text/Editorial column (Col: 1-6) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 text-left space-y-6"
            id="philosophy-text-wrapper"
          >
            <div className="space-y-2">
              <div className="font-sans text-xs uppercase tracking-[0.25em] text-rose-dusty font-bold flex items-center gap-2">
                <span className="h-[1px] w-6 bg-rose-dusty" /> Core Belief
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-charcoal font-light tracking-tight leading-tight">
                Beauty Without <br />
                <span className="italic font-light text-rose-dusty">Chasing Trends.</span>
              </h2>
            </div>

            <div className="font-sans text-xs sm:text-sm text-charcoal/80 leading-relaxed space-y-5">
              <p className="text-sm sm:text-base italic text-charcoal/90 font-medium border-l border-sage pl-4 py-0.5">
                “I believe looking your best doesn’t require buying more clothes or chasing every new trend. Instead, confidence comes from understanding what works for you, embracing natural beauty, and making the most of what you already own.”
              </p>
              
              <p>
                Together, we’ll uncover the treasures already hanging in your closet and create a style that feels authentic, flattering, and uniquely yours.
              </p>
              
              <p>
                As we age, our bodies change and our skincare needs shift, but so does our clarity of self. True style isn't about hiding or desperately attempting to look decades younger. It is about aligning your external presentation with the wisdom, maturity, and beautiful strength you hold inside if given the correct, gentle guidance.
              </p>
            </div>

            {/* Aesthetic quote signoff */}
            <div className="pt-4 border-t border-warm-beige-light">
              <div className="font-serif italic text-base text-rose-dusty font-medium">Melanie Jackson</div>
              <div className="font-sans text-[9px] uppercase tracking-[0.15em] text-charcoal/50 mt-1">Founder, Aesthetics & Style</div>
            </div>
          </motion.div>

          {/* Wardrobe imagery illustration column (Col: 7-12) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.9, delay: 0.1 }}
            className="mt-12 lg:mt-0 lg:col-span-6 relative flex justify-center"
          >
            <div className="arched-image border-4 border-white shadow-sm bg-white max-w-md border-thin border-warm-beige relative">
              {wardrobeImageUrl && (
                <img
                  src={wardrobeImageUrl}
                  alt="Melanie Jackson demonstrating professional wardrobe styling with a tailored white blazer and custom grey vest"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover object-center aspect-[4/3] hover:scale-[1.02] transition-transform duration-700"
                  id="philosophy-wardrobe-image"
                />
              )}
              
              <div className="p-5 sm:p-6 bg-white border-t border-warm-beige text-left">
                <h4 className="font-serif text-sm font-semibold text-charcoal">Textures, Fabrics & Layering</h4>
                <p className="font-sans text-xs text-charcoal/70 mt-1.5 leading-relaxed">
                  Melanie demonstrates how custom layers of varied textures and fabrics create interest. Experimenting with mixed patterns, which normally may have seemed too daring, can elevate your style once you have the right guidance.
                </p>
              </div>
            </div>
          </motion.div>
          
        </div>
      </div>
    </section>
  );
}
