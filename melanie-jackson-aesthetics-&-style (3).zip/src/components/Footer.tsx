import React, { useState } from 'react';
import { ArrowUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Footer() {
  const [showPrivacy, setShowPrivacy] = useState(false);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      const offset = 80;
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-charcoal text-white pt-16 pb-8 border-t border-white/5" id="main-footer">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-white/10 text-left">
          {/* Logo & Tagline column (Col: 1-5) */}
          <div className="md:col-span-5 space-y-4">
            <h3 className="font-serif text-lg sm:text-xl tracking-[0.1em] font-light hover:text-rose-dusty transition-colors cursor-pointer select-none" onClick={handleScrollToTop}>
              MELANIE JACKSON
            </h3>
            <p className="font-sans text-[9px] uppercase tracking-[0.3em] text-white/40 -mt-3">
              Aesthetics & Style
            </p>
            <p className="font-sans text-xs text-white/60 leading-relaxed max-w-sm pt-2">
              Natural Beauty. Timeless Style. Confident Living. Melanie empowers clients of all ages and genders to embrace wellness, discover curated wardrobing potential, and feel confident at every stage.
            </p>
          </div>

          {/* Quick Links Column (Col: 6-8) */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] font-bold text-rose-dusty">Navigate</h4>
            <ul className="space-y-2.5 font-sans text-xs text-white/50">
              {['About', 'Services', 'Philosophy', 'Contact'].map((item) => (
                <li key={item}>
                  <a
                    href={`#${item.toLowerCase()}`}
                    onClick={(e) => handleLinkClick(e, `#${item.toLowerCase()}`)}
                    className="hover:text-white transition-colors block"
                    id={`footer-nav-${item.toLowerCase()}`}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact details Column (Col: 9-12) */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] font-bold text-rose-dusty">Contact Details</h4>
            <div className="font-sans text-xs text-white/60 leading-relaxed space-y-1">
              <p>Phone: <a href="tel:+16138780900" className="hover:text-rose-dusty transition-all">(613) 878-0900</a></p>
              <p>Email: <a href="mailto:mj@melaniejacksonstyle.com" className="hover:text-rose-dusty transition-all">mj@melaniejacksonstyle.com</a></p>
              <p className="pt-2 text-white/40 text-[11px]">By Appointment Only</p>
            </div>
            
            <button
              onClick={() => setShowPrivacy(true)}
              className="inline-flex items-center gap-1.5 pt-2 text-rose-dusty hover:text-white font-sans text-[11px] uppercase tracking-wider transition-colors cursor-pointer"
              id="footer-privacy-trigger"
            >
              Read Privacy Policy
            </button>
          </div>
        </div>

        {/* Footer bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-8 gap-4 font-sans text-[11px] text-white/30 font-light">
          <div>
            Copyright &copy; {new Date().getFullYear()} Melanie Jackson Aesthetics & Style. All rights reserved.
          </div>
          
          <button
            onClick={handleScrollToTop}
            className="group flex items-center gap-1.5 rounded-full border border-white/10 hover:border-white/30 px-3.5 py-1.5 text-white/60 hover:text-white transition-all cursor-pointer text-[10px] uppercase tracking-wider"
            id="scroll-to-top-btn"
          >
            Back to top <ArrowUp className="h-3 w-3 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

      </div>

      {/* Privacy Policy Dialog modal */}
      <AnimatePresence>
        {showPrivacy && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPrivacy(false)}
              className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm"
              id="privacy-backdrop"
            />

            {/* Panel (Flat Swiss Minimalist box) */}
            <motion.div
              initial={{ opacity: 0, scale: 0.98, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: 15 }}
              className="relative z-10 w-full max-w-lg overflow-hidden rounded-none bg-ivory text-charcoal border border-warm-beige p-6 sm:p-8 shadow-none"
              id="privacy-modal-panel"
            >
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-warm-beige-light pb-3">
                  <h3 className="font-serif text-lg text-charcoal font-medium">Privacy & Booking Policy</h3>
                </div>

                <div className="font-sans text-xs space-y-3 leading-relaxed text-charcoal/70 max-h-[50vh] overflow-y-auto pr-1">
                  <p className="font-semibold text-charcoal">1. Information Protection</p>
                  <p>
                    Melanie Jackson Aesthetics & Style strictly protects client information submitted via online consultation or booking processes. Your contact coordinates, age ranges, and self-disclosed skin or wardrobe notes are strictly managed and never sold or shared.
                  </p>
                  
                  <p className="font-semibold text-charcoal">2. Cancelation & Rescheduling Policy</p>
                  <p>
                    Because Melanie reserves dedicated blocks of 60 to 90 minutes specifically to style or treat one client, we kindly request at least 24 hours warning before cancelations. Missing or rescheduling appointments with under 24 hours notice may result in a consultation booking charge.
                  </p>

                  <p className="font-semibold text-charcoal">3. Consent</p>
                  <p>
                    By submitting a consultation request on this website, you consent to receive direct emails or text confirmations regarding booking schedules from Melanie.
                  </p>
                </div>

                <div className="pt-4 flex justify-end border-t border-warm-beige-light">
                  <button
                    onClick={() => setShowPrivacy(false)}
                    className="border border-charcoal/15 hover:border-charcoal px-5 py-2 font-sans text-[10px] font-bold uppercase tracking-widest cursor-pointer"
                    id="privacy-modal-close"
                  >
                    I Understand
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </footer>
  );
}
