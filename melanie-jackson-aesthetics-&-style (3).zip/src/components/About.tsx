import React from 'react';
import { Check } from 'lucide-react';
import { motion } from 'motion/react';

interface AboutProps {
  portraitImageUrl?: string;
  onOpenBooking: () => void;
}

export default function About({ portraitImageUrl, onOpenBooking }: AboutProps) {
  return (
    <section className="py-20 lg:py-28 bg-warm-beige-light overflow-hidden scroll-mt-12" id="about">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
          
          {/* Portrait Image Column (Col: 1-5) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative"
          >
            {/* Elegant Arched Portrait */}
            <div className="arched-image border-4 border-white shadow-sm aspect-[3/4] bg-warm-beige max-w-md mx-auto relative z-10">
              {portraitImageUrl && (
                <img
                  src={portraitImageUrl}
                  alt="Melanie Jackson close-up portrait styled in a classic checkered tie and dark vest"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top scale-[1.01] hover:scale-[1.03] transition-transform duration-500"
                  id="about-melanie-portrait"
                />
              )}
            </div>

            {/* Float Badge with Clean Thin Border */}
            <div className="absolute -bottom-6 -right-2 bg-white border border-warm-beige p-5 rounded-none shadow-none max-w-[210px] text-left z-20">
              <p className="font-serif text-3xl font-light text-sage leading-none">25+</p>
              <p className="font-sans text-[9px] uppercase font-bold tracking-widest text-charcoal mt-2">Years of True Integrity</p>
              <p className="font-sans text-[11px] text-charcoal/60 mt-0.5">Personal Skincare & Style Advisor</p>
            </div>
          </motion.div>

          {/* Text/Content Column (Col: 6-12) */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="mt-16 lg:mt-0 lg:col-span-7 text-left space-y-6"
            id="about-melanie-text-container"
          >
            <div className="space-y-2">
              <div className="text-xs uppercase tracking-[0.2em] text-rose-dusty font-semibold">The Woman Behind the Practice</div>
              <h2 className="font-serif text-3xl sm:text-4xl text-charcoal font-light">Meet Melanie Jackson</h2>
            </div>

            <div className="font-sans text-xs sm:text-sm text-charcoal/80 leading-relaxed space-y-4">
              <p className="border-l-2 border-[#818a7c] pl-4 py-1 italic text-charcoal/90 font-medium">
                “With over 25 years of experience as a licensed aesthetician, stylist, and wardrobe consultant, I help clients of all backgrounds look and feel their best by embracing a natural, confident approach to beauty and style.”
              </p>
              
              <p>
                As an experienced practitioner, I understand firsthand how our skin, style needs, and sense of self evolve over time. Working with clients of all ages, my philosophy is simple: true style isn’t about buying more—it’s about discovering the potential within what you already own and learning how to wear it in a way that reflects who you are today.
              </p>

              <p>
                Through personalized guidance in skincare, healthy aging, and wardrobe styling, I empower individuals of all genders to enhance their confidence, celebrate their individuality, and create a look that feels authentic and effortless.
              </p>
            </div>

            {/* Signature & Title section */}
            <div className="pt-6 border-t border-warm-beige flex flex-col text-left">
              <span className="font-serif font-bold text-sm text-charcoal/80">Melanie Jackson</span>
              <span className="font-sans text-[10px] text-charcoal/50 uppercase tracking-[0.15em] mt-0.5">Licensed Aesthetician & Style Advisor</span>
            </div>

          </motion.div>
        </div>
      </div>
    </section>
  );
}
