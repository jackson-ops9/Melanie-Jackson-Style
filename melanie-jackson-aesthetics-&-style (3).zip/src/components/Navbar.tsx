import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onOpenBooking: () => void;
}

export default function Navbar({ onOpenBooking }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Philosophy', href: '#philosophy' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      const offset = 80; // height of compressed header
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? 'bg-ivory/95 border-b border-warm-beige-light/90 backdrop-blur-md py-3 shadow-none'
            : 'bg-transparent py-5'
        }`}
        id="main-navigation"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-12 items-center justify-between">
            {/* Logo */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex flex-col group select-none cursor-pointer"
              id="navigation-brand-logo"
            >
              <div className="font-serif text-lg tracking-[0.1em] sm:text-xl font-light text-charcoal group-hover:text-rose-dusty transition-colors duration-200">
                MELANIE JACKSON
              </div>
              <div className="font-sans text-[8px] sm:text-[9px] uppercase tracking-[0.3em] text-charcoal/50 group-hover:text-charcoal transition-colors duration-200 -mt-0.5">
                Aesthetics & Style
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center space-x-7">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="font-sans text-[11px] font-medium uppercase tracking-[0.2em] text-charcoal/75 hover:text-rose-dusty transition-colors duration-200"
                  id={`nav-link-${link.name.toLowerCase()}`}
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Desktop CTA Button */}
            <div className="hidden md:flex items-center">
              <button
                onClick={onOpenBooking}
                className="bg-sage hover:bg-sage-dark text-white px-6 py-2 rounded-full text-[11px] font-bold uppercase tracking-widest transition-all duration-300 shadow-none cursor-pointer"
                id="navbar-book-cta-desktop"
              >
                Request Service
              </button>
            </div>

            {/* Mobile Menu Toggle Button */}
            <div className="flex md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="rounded-full p-1.5 text-charcoal/70 hover:bg-warm-beige-light hover:text-charcoal transition-all duration-250"
                id="toggle-mobile-menu"
                aria-label="Toggle menu"
              >
                {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="absolute top-full left-0 right-0 z-40 bg-ivory border-b border-warm-beige-light px-4 py-6 shadow-none md:hidden"
              id="mobile-navigation-links"
            >
              <div className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={(e) => handleLinkClick(e, link.href)}
                    className="font-sans text-xs font-semibold uppercase tracking-widest text-charcoal/80 hover:text-rose-dusty py-1.5 border-b border-warm-beige-light/50"
                    id={`mobile-link-${link.name.toLowerCase()}`}
                  >
                    {link.name}
                  </a>
                ))}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      onOpenBooking();
                    }}
                    className="flex w-full items-center justify-center rounded-full bg-sage hover:bg-sage-dark text-white py-3 font-sans text-xs font-bold tracking-widest uppercase transition-all duration-200"
                    id="navbar-book-cta-mobile"
                  >
                    Request Service
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}
