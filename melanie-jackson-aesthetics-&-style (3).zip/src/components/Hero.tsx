import React from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onOpenBooking: () => void;
  heroImageUrl?: string;
  portraitImageUrl?: string;
  wardrobeImageUrl?: string;
}

export default function Hero({ onOpenBooking, heroImageUrl, portraitImageUrl, wardrobeImageUrl }: HeroProps) {
  const scrollToServices = (e: React.MouseEvent) => {
    e.preventDefault();
    const target = document.querySelector('#services');
    if (target) {
      const offset = 80;
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="relative overflow-hidden pt-28 pb-16 lg:pt-36 lg:pb-24 bg-ivory" id="hero-section">
      {/* Delicate ambient background patterns */}
      <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-sage-light/40 blur-3xl pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-12 items-center">
          {/* Text content (Col: 1-7) */}
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="flex flex-col space-y-6 lg:col-span-7 text-left"
          >
            {/* Elegant Sub-Header */}
            <div className="text-xs uppercase tracking-[0.3em] text-sage font-bold flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-sage" />
              Natural Beauty &bull; Timeless Style
            </div>

            {/* Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-5xl xl:text-6xl text-charcoal font-light leading-[1.1] tracking-tight">
              Helping You <br />
              <span className="italic font-light text-rose-dusty">Look & Feel</span> <br />
              Your Best At Every Stage.
            </h1>

            {/* Subheadline */}
            <p className="font-sans text-sm sm:text-base text-charcoal/70 leading-relaxed max-w-xl">
              With over 25 years of experience, Melanie Jackson empowers clients of all ages and genders to discover their style potential, cultivate radiant skin, and live confidently.
            </p>

            {/* CTA Container */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onOpenBooking}
                className="group bg-sage hover:bg-sage-dark text-white px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 shadow-sm cursor-pointer"
                id="hero-book-cta-btn"
              >
                Request Consultation
              </button>

              <a
                href="#services"
                onClick={scrollToServices}
                className="group flex items-center justify-center gap-2 rounded-full border border-charcoal/20 hover:border-charcoal bg-transparent px-7 py-3 font-sans text-xs font-bold tracking-widest uppercase text-charcoal transition-all duration-200"
                id="hero-services-cta-btn"
              >
                View Services <ArrowRight className="h-3.5 w-3.5 text-charcoal/50 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Tagline Footer */}
            <div className="border-t border-warm-beige-light pt-6 mt-4 grid grid-cols-3 gap-4">
              {[
                { label: 'Natural Beauty', desc: 'Embrace healthy aging' },
                { label: 'Timeless Style', desc: 'Uncover your identity' },
                { label: 'Confident Living', desc: 'Own your presence' },
              ].map((item, id) => (
                <div key={id} className="space-y-1">
                  <p className="font-serif text-sm font-semibold text-charcoal leading-none">{item.label}</p>
                  <p className="font-sans text-[11px] text-charcoal/50">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Large Image (Col: 8-12) */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.0, ease: 'easeOut' }}
            className="mt-12 lg:mt-0 lg:col-span-5 relative flex flex-col items-center"
          >
            {/* Arched image container based on theme request */}
            <div className="relative arched-image border-4 border-white shadow-md max-w-full w-[360px] aspect-[3/4] bg-warm-beige overflow-hidden">
              {heroImageUrl && (
                <img
                  src={heroImageUrl}
                  alt="Melanie Jackson styled in a chic soft rose-gold metallic blazer, gold metallic top, and white wide-leg trousers, holding a geometric-patterned gold clutch"
                  className="w-full h-full object-cover object-top hover:scale-[1.02] transition-transform duration-700"
                  id="hero-banner-image"
                />
              )}

              {/* Overlay Signature Tag */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-charcoal/95 backdrop-blur-sm text-ivory text-[9px] uppercase font-semibold tracking-widest px-4 py-1.5 rounded-full select-none whitespace-nowrap z-20">
                <span>Structure &bull; Editing &bull; Balance</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
