import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X, Check, ArrowRight, Loader2, Calendar } from 'lucide-react';
import { SERVICES } from '../data';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedServiceId?: string;
  onBookingSuccess?: (details: any) => void;
}

export default function BookingModal({ isOpen, onClose, preselectedServiceId }: BookingModalProps) {
  const [selectedServiceId, setSelectedServiceId] = useState('');
  
  // Form fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [contactMethod, setContactMethod] = useState<'email' | 'text'>('email');
  const [goals, setGoals] = useState('');

  // Status flags
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [bookingRef, setBookingRef] = useState('');

  // Set initial service selection when opening
  useEffect(() => {
    if (isOpen) {
      setSelectedServiceId(preselectedServiceId || SERVICES[0]?.id || '');
      setSubmitError(null);
    }
  }, [isOpen, preselectedServiceId]);

  if (!isOpen) return null;

  const selectedService = SERVICES.find(s => s.id === selectedServiceId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Client-side validations
    if (!firstName || !lastName) {
      setSubmitError('First and last name are required.');
      return;
    }
    if (!email) {
      setSubmitError('Email address is required.');
      return;
    }
    if (!phone) {
      setSubmitError('Phone number is required.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    // Generate reference code
    const generatedRef = 'MJ-' + Math.floor(100000 + Math.random() * 900000);

    const payload = {
      "Reference Number": generatedRef,
      "Requested Service": selectedService ? `${selectedService.name} ($${selectedService.price || 'Consult'})` : 'General Style & Aesthetics Consult',
      "First Name": firstName,
      "Last Name": lastName,
      "Email Address": email,
      "Phone Number": phone,
      "Preferred Contact Channel": contactMethod === 'email' ? 'Email' : 'Phone / Text',
      "Treatment Goals / Wardrobe Notes": goals || 'No notes provided.'
    };

    try {
      const response = await fetch('https://formspree.io/f/xbdeorwd', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setBookingRef(generatedRef);
        setIsSuccess(true);
      } else {
        const errorData = await response.json();
        setSubmitError(errorData.error || 'There was a problem submitting your request. Please try again.');
      }
    } catch (error) {
      setSubmitError('A connection problem occurred. Please check your network and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFirstName('');
    setLastName('');
    setEmail('');
    setPhone('');
    setContactMethod('email');
    setGoals('');
    setIsSuccess(false);
    setSubmitError(null);
  };

  const handleClose = () => {
    onClose();
    // Allow animation to complete before resetting form fields
    setTimeout(() => {
      resetForm();
    }, 300);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="booking-modal-portal">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
          className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm"
          id="booking-backdrop"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.98, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="relative z-10 w-full max-w-xl overflow-hidden rounded-none bg-[#FAF9F5] shadow-2xl border border-warm-beige"
          id="booking-modal-container"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-warm-beige-light bg-[#FAF9F5] p-5">
            <div>
              <h3 className="font-serif text-lg text-charcoal font-semibold">
                {isSuccess ? 'Inquiry Submitted' : 'Request an Appointment'}
              </h3>
              <p className="font-sans text-xs text-charcoal/50 mt-0.5">
                {isSuccess ? 'Thank you for your interest' : 'Melanie Jackson Aesthetics & Style'}
              </p>
            </div>
            <button
              onClick={handleClose}
              className="rounded-full p-1.5 text-charcoal/60 hover:bg-warm-beige-light hover:text-charcoal transition-all"
              id="close-booking-modal"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {!isSuccess ? (
            <form onSubmit={handleSubmit} className="space-y-0" id="booking-details-form">
              {/* Form Content Area */}
              <div className="max-h-[65vh] overflow-y-auto px-6 py-5 text-left space-y-4">
                <p className="font-sans text-xs text-charcoal/70 leading-relaxed">
                  Select your desired service and provide your details below. Melanie will reach out directly to coordinate your treatment options or wardrobe style session.
                </p>

                {/* Service Selector Dropdown */}
                <div>
                  <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                    Select Service *
                  </label>
                  <select
                    value={selectedServiceId}
                    onChange={(e) => setSelectedServiceId(e.target.value)}
                    className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all appearance-none cursor-pointer"
                    id="booking-select-service"
                  >
                    {SERVICES.map((service) => (
                      <option key={service.id} value={service.id}>
                        {service.name} — {service.duration || 'Session'} (${service.price})
                      </option>
                    ))}
                  </select>
                </div>

                {/* First and Last Name */}
                <div className="grid grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                      First Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                      placeholder="Sarah"
                      id="booking-input-firstname"
                    />
                  </div>
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                      placeholder="Jenkins"
                      id="booking-input-lastname"
                    />
                  </div>
                </div>

                {/* Contact Coordinates (Both REQUIRED) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                      placeholder="sarah@example.com"
                      id="booking-input-email"
                    />
                  </div>
                  <div>
                    <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all"
                      placeholder="(555) 000-0000"
                      id="booking-input-phone"
                    />
                  </div>
                </div>

                {/* Preferred Contact Method Selection */}
                <div>
                  <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-2">
                    Preferred Contact Method *
                  </label>
                  <div className="flex flex-col sm:flex-row gap-5 pt-1">
                    <label className="flex items-center space-x-2.5 cursor-pointer select-none font-sans text-xs text-charcoal" id="booking-pref-email-label">
                      <input
                        type="checkbox"
                        checked={contactMethod === 'email'}
                        onChange={() => setContactMethod('email')}
                        className="h-4 w-4 border-warm-beige text-charcoal focus:ring-0 focus:outline-none rounded-none accent-charcoal cursor-pointer"
                        id="booking-pref-email"
                      />
                      <span>Reach out via Email</span>
                    </label>
                    <label className="flex items-center space-x-2.5 cursor-pointer select-none font-sans text-xs text-charcoal" id="booking-pref-phone-label">
                      <input
                        type="checkbox"
                        checked={contactMethod === 'text'}
                        onChange={() => setContactMethod('text')}
                        className="h-4 w-4 border-warm-beige text-charcoal focus:ring-0 focus:outline-none rounded-none accent-charcoal cursor-pointer"
                        id="booking-pref-phone"
                      />
                      <span>Reach out via Phone / Text</span>
                    </label>
                  </div>
                </div>

                {/* Customer Goals Statement */}
                <div>
                  <label className="block font-sans text-[10px] uppercase font-bold tracking-widest text-[#888075] mb-1.5">
                    Treatment Goals or Styling Ideas
                  </label>
                  <textarea
                    rows={3}
                    value={goals}
                    onChange={(e) => setGoals(e.target.value)}
                    className="w-full rounded-none border border-warm-beige bg-[#FAF9F5] px-3.5 py-2.5 font-sans text-xs text-charcoal focus:border-charcoal focus:outline-none focus:bg-white transition-all resize-none"
                    placeholder="Tell us about your skincare concerns, style aspirations, or wardrobe objectives..."
                    id="booking-input-goals"
                  />
                </div>

                {submitError && (
                  <div className="bg-red-50 text-red-650 p-3.5 border-l-2 border-red-500 font-sans text-xs leading-normal">
                    {submitError}
                  </div>
                )}
              </div>

              {/* Submit Footer Panel */}
              <div className="flex items-center justify-between border-t border-warm-beige-light bg-[#FAF9F5] p-5">
                <span className="font-sans text-[10px] text-charcoal/40 uppercase tracking-wider">
                  No immediate charge
                </span>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-charcoal hover:bg-charcoal/90 text-white px-7 py-2.5 rounded-full font-sans text-[10px] uppercase tracking-widest font-bold transition-all cursor-pointer flex items-center justify-center gap-2 min-w-[140px] disabled:opacity-75 disabled:cursor-not-allowed"
                  id="booking-submit-btn"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      Submit Request
                      <ArrowRight className="h-3 w-3" />
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* Success screen state */
            <div className="p-8 text-center space-y-6 bg-white overflow-y-auto max-h-[80vh]">
              <div className="space-y-3">
                <div className="w-12 h-12 bg-sage/10 text-sage rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="h-6 w-6 text-emerald-600" />
                </div>
                <h4 className="font-serif text-lg text-charcoal font-bold tracking-wide">
                  Request Received Successfully
                </h4>
                <p className="max-w-md mx-auto font-sans text-xs text-charcoal/70 leading-relaxed">
                  Thank you, <span className="font-semibold text-charcoal">{firstName} {lastName}</span>. Melanie Jackson has been notified of your service inquiry and will reach out to you via <span className="font-semibold text-charcoal">{contactMethod === 'email' ? 'Email' : 'Text Message'}</span> shortly.
                </p>
              </div>

              {/* Inquiry details summary */}
              <div className="mx-auto max-w-sm border border-warm-beige bg-[#FAF9F5]/40 p-5 space-y-3 text-left font-sans text-xs">
                <div className="flex justify-between border-b border-warm-beige-light pb-2">
                  <span className="text-charcoal/50 uppercase tracking-widest text-[9px]">Inquiry Ref</span>
                  <span className="font-mono font-bold tracking-wider text-charcoal">{bookingRef}</span>
                </div>
                <div className="space-y-2 pt-1">
                  <div>
                    <span className="text-charcoal/50 text-[10px] uppercase tracking-widest block">Selected Service</span>
                    <p className="font-semibold text-charcoal text-xs">{selectedService?.name}</p>
                    {selectedService?.duration && (
                      <p className="text-charcoal/50 text-[10px]">{selectedService.duration} | ${selectedService.price}</p>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-warm-beige-light/30">
                    <div>
                      <span className="text-charcoal/50 text-[10px] uppercase tracking-widest block">Contact Coordinates</span>
                      <p className="font-medium text-charcoal text-xs truncate">
                        {contactMethod === 'email' ? email : phone}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-charcoal/50 text-[10px] uppercase tracking-widest block">Response Method</span>
                      <p className="font-medium text-charcoal text-xs">By {contactMethod === 'email' ? 'Email' : 'SMS Text'}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleClose}
                  className="bg-charcoal hover:bg-charcoal/90 text-white px-8 py-3 rounded-full font-sans text-[10px] font-bold uppercase tracking-widest cursor-pointer"
                  id="booking-success-close"
                >
                  Return to Website
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
