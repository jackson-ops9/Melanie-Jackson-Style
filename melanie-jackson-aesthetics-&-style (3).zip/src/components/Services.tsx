import React, { useState } from 'react';
import { Clock, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SERVICES } from '../data';

interface ServicesProps {
  onSelectService: (serviceId: string) => void;
}

export default function Services({ onSelectService }: ServicesProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'skincare' | 'beauty' | 'style'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', name: 'All Services' },
    { id: 'skincare', name: 'Facials & Skincare' },
    { id: 'beauty', name: 'Beauty Services' },
    { id: 'style', name: 'Style & Wardrobe' },
  ];

  const filteredServices = SERVICES.filter((s) => {
    const matchesTab = activeTab === 'all' || s.category === activeTab;
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          s.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <section className="py-20 lg:py-28 bg-ivory border-t border-b border-warm-beige-light/60 scroll-mt-12" id="services">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="font-sans text-[11px] font-bold uppercase tracking-[0.25em] text-rose-dusty">The Treatment Menu</div>
          <h2 className="font-serif text-3xl sm:text-4xl text-charcoal font-light">Bespoke Skincare & Styling</h2>
          <p className="font-sans text-xs sm:text-sm text-charcoal/70 leading-relaxed max-w-xl mx-auto">
            Every treatment is customized to your unique profile on the day of appointment, designed elegantly to support natural aging and personal refinement.
          </p>
        </div>

        {/* Toolbar: Category Selector and Quick Search */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-warm-beige-light pb-6 mb-10">
          {/* Tabs Container */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {categories.map((cat) => {
              const isActive = activeTab === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id as any)}
                  className={`px-5 py-2 font-sans text-[10px] font-semibold uppercase tracking-widest transition-all duration-300 rounded-full border ${
                    isActive
                      ? 'bg-sage text-white border-sage'
                      : 'border-warm-beige text-charcoal/60 bg-transparent hover:border-charcoal hover:text-charcoal'
                  }`}
                  id={`tab-button-${cat.id}`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>

          {/* Minimalist Search Bar */}
          <div className="relative w-full md:w-64">
            <input
              type="text"
              placeholder="Search services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-warm-beige bg-white/40 pl-9 pr-4 py-1.5 font-sans text-[11px] text-charcoal placeholder-charcoal/40 focus:border-sage focus:outline-none transition-all"
              id="services-search-input"
            />
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-3 w-3 text-charcoal/40" />
          </div>
        </div>

        {/* Services Grid Display */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          id="services-grid"
        >
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service) => (
              <motion.div
                layout
                key={service.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
                className="group flex flex-col justify-between border-thin border-warm-beige bg-white p-6 shadow-none transition-all duration-300 hover:border-sage"
                id={`service-card-${service.id}`}
              >
                <div>
                  {/* Category Pill and Duration Tag */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-sans text-[9px] font-bold uppercase tracking-widest text-rose-dusty">
                      {service.category === 'skincare' 
                        ? 'Facial & Skincare' 
                        : service.category === 'beauty' 
                        ? 'Beauty Accent' 
                        : 'Style & Wardrobe'}
                    </span>
                    {service.duration && (
                      <span className="flex items-center gap-1 font-sans text-[10px] text-charcoal/50">
                        <Clock className="h-3 w-3 text-sage/70" /> {service.duration}
                      </span>
                    )}
                  </div>

                  {/* Title and Price */}
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <h3 className="font-serif text-base text-charcoal font-medium group-hover:text-rose-dusty transition-colors duration-250">
                      {service.name}
                    </h3>
                    <div className="font-sans text-xs font-semibold text-charcoal bg-warm-beige-light px-2 py-0.5 border border-warm-beige/30">
                      ${service.price}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="font-sans text-xs text-charcoal/60 leading-relaxed mb-6 mt-1">
                    {service.description}
                  </p>
                </div>

                {/* Book Action Button */}
                <button
                  onClick={() => onSelectService(service.id)}
                  className="w-full text-center border border-charcoal/10 hover:border-charcoal hover:bg-charcoal hover:text-white py-2.5 font-sans text-[10px] font-bold uppercase tracking-widest transition-all duration-300 cursor-pointer"
                  id={`book-service-btn-${service.id}`}
                >
                  Request Service
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty Search Result Fallback */}
        {filteredServices.length === 0 && (
          <div className="text-center py-12 bg-white border border-warm-beige p-6">
            <p className="font-sans text-xs text-charcoal/60">No services match your search inquiry.</p>
            <button
              onClick={() => {
                setActiveTab('all');
                setSearchQuery('');
              }}
              className="mt-3 font-sans text-[10px] font-bold text-rose-dusty hover:text-rose-dark uppercase tracking-widest"
              id="clear-service-filters-btn"
            >
              Reset Filters & Search
            </button>
          </div>
        )}

        {/* Booking Consultation Package Banner */}
        <div className="mt-16 bg-white border border-warm-beige p-6 sm:p-10 lg:p-12 relative flex flex-col md:flex-row items-center justify-between gap-6 shadow-none">
          <div className="absolute top-0 left-0 h-[2px] bg-sage w-full" />
          <div className="text-left max-w-2xl space-y-1.5">
            <h3 className="font-serif text-lg text-charcoal font-light">Not sure which treatment suits your skin or wardrobe?</h3>
            <p className="font-sans text-xs text-charcoal/60 leading-relaxed">
              We highly recommend starting with our expert <span className="font-semibold text-charcoal">Skin Care Consultation</span> ($50) or the comprehensive <span className="font-semibold text-charcoal">First Style Appointment Welcome Package</span> ($100) to draft a tailored roadmap.
            </p>
          </div>
          <button
            onClick={() => onSelectService('skincare-consult')}
            className="bg-sage hover:bg-sage-dark text-white px-6 py-3 rounded-full font-sans text-[10px] font-bold tracking-widest uppercase flex-shrink-0 transition-colors shadow-none cursor-pointer"
            id="book-consultation-banner-btn"
          >
            Start Consultation
          </button>
        </div>

      </div>
    </section>
  );
}
