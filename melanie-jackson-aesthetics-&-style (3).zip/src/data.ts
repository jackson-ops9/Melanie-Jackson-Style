import { Service, Testimonial, GalleryItem } from './types';
import roseGoldImage from './assets/images/woman_hero_50_1780778357820.png';

export const SERVICES: Service[] = [
  // Facials & Skincare
  {
    id: 'luxe-facial',
    name: '90 Minute Luxe Facial with Peel',
    price: 200,
    duration: '90 Min',
    category: 'skincare',
    description: 'Our ultimate anti-aging facial. Combines cellular-stimulating massage with a customized refining peel to deeply resurface, lift, and sculpt mature skin.',
    squareServiceId: '', // Replace with your Square Service ID to deep link directly (e.g. 'SF12345')
  },
  {
    id: 'biopeptide-facial',
    name: 'BioPeptide Hydration Facial',
    price: 160,
    duration: '75 Min',
    category: 'skincare',
    description: 'Floods the skin with potent peptides and multi-weight hyaluronic acid to immediately plump fine lines, restore moisture barriers, and boost firmness.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'brightening-peel',
    name: 'Brightening & Refining Peel',
    price: 165,
    duration: '60 Min',
    category: 'skincare',
    description: 'Targets hyperpigmentation, age spots, and uneven texture. This advanced medical-grade exfoliation reveals brilliant, luminous skin with zero downtime.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'cryo-facial',
    name: 'Cooling Cryo Soothing Facial',
    price: 150,
    duration: '60 Min',
    category: 'skincare',
    description: 'Invigorating cold-therapy facial designed to reduce puffiness, stimulate circulation, soothe sensitivity, and leave skin incredibly taut and glowing.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'elaspa-facial',
    name: 'Elaspa Customized Facial',
    price: 130,
    duration: '60 Min',
    category: 'skincare',
    description: 'A completely bespoke facial utilizing premium, certified-organic Elaspa active ingredients, personalized for your specific skin concerns.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'aha-facial',
    name: 'Facial with AHA',
    price: 175,
    duration: '75 Min',
    category: 'skincare',
    description: 'Utilizes alpha hydroxy acids to gently break down dead skin cells and build-up, encouraging rapid cell turnover and smooth, youthful clarity.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'purifying-facial',
    name: 'Purifying Teen Facial',
    price: 100,
    duration: '60 Min',
    category: 'skincare',
    description: 'A deep-cleansing facial targeting impurities, decongesting pores, and restoring a balanced oil and moisture barrier.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'eye-treatment',
    name: 'Eye Treatment',
    price: 20,
    duration: '20 Min',
    category: 'skincare',
    description: 'A specialized treatment adding firming microcurrents, cooling globes, and hydrating peptides to brighten, lift, and depuff the eye area.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'skincare-consult',
    name: 'Skin Care Consultation',
    price: 50,
    duration: '30 Min',
    category: 'skincare',
    description: 'A holistic analysis of your skin health, aging goals, and daily routine. Includes customized product recommendations with no brand bias.',
    squareServiceId: '', // Replace with your Square Service ID
  },
 
  // Beauty Services
  {
    id: 'brow-tint',
    name: 'Brow Tint',
    price: 25,
    duration: '15 Min',
    category: 'beauty',
    description: 'Individually mixed tint to frame your face and beautifully define thin, blonde, or gray brow hairs to restore youthful fullness.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'lash-tint',
    name: 'Lash Tint',
    price: 30,
    duration: '20 Min',
    category: 'beauty',
    description: 'Deep, rich dark-pigmented tinting of your natural eyelashes to make eyes appear open, bright, and defined without the need for mascara.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'makeup-app',
    name: 'Make-up Application',
    price: 90,
    duration: '45 Min',
    category: 'beauty',
    description: 'Flawless makeup application focused on skin-glowing, age-embracing, light-reflective techniques for any special event or portrait.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'makeup-lesson',
    name: 'Make-up Lesson',
    price: 150,
    duration: '90 Min',
    category: 'beauty',
    description: 'Hands-on tutorial centered on refreshing your technique. Learn which colors, textures, and formulas elevate mature skin beautifully and naturally. As well as editing the contents of your make up bag.',
    squareServiceId: '', // Replace with your Square Service ID
  },
 
  // Style & Wardrobe
  {
    id: 'first-style',
    name: 'First Style Appointment Welcome',
    price: 100,
    duration: '90 Min',
    category: 'style',
    description: 'Our starter styling session includes an opportunity to discuss your style needs. We will edit your wardrobe and design capsules to make everyday dressing enjoyable.',
    squareServiceId: '', // Replace with your Square Service ID
  },
  {
    id: 'style-app',
    name: 'Style Appointment',
    price: 100,
    duration: '60 Min',
    category: 'style',
    description: 'Targeted styling session focused on creating looks with items you already own. Shop your own closet to discover exciting new outfit combinations and maximize your wardrobe potential.',
    squareServiceId: '', // Replace with your Square Service ID
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Eleanor Vance',
    age: 62,
    quote: "I thought my skin's dry, dull texture was just a natural part of turning 60 that I had to accept. After three customized Luxe Facials with Melanie, my face is actually glowing and feels so soft. Melanie taught me how to nourish my skin, not fight it.",
    category: 'Skincare Advice',
  },
  {
    id: 'test-2',
    name: 'Robert Chen',
    age: 52,
    quote: "As a professional man, I initially didn't think style coaching or skincare was for me. Melanie's wardrobe audit and skin therapy changed my perspective completely. She helped me build a versatile capsule closet of high-quality fits that elevated my executive presence.",
    category: 'Wardrobe & Skincare',
  },
  {
    id: 'test-3',
    name: 'Evelyn Reed',
    age: 32,
    quote: "I wanted a sustainable skincare routine and style guide that was timeless, not trendy. Melanie helped me build a perfect capsule wardrobe and clear skin habits. Her lesson saved me time and money, and she is incredibly knowledgeable.",
    category: 'Timeless Style',
  },
  {
    id: 'test-4',
    name: 'Thomas Bennett',
    age: 41,
    quote: "Melanie's personalized approach to skincare and grooming has been a game-changer. She addressed my shave-irritated skin and rough texture, giving me an effortless daily routine. Her professionalism and deep style expertise are unmatched.",
    category: 'Personal Grooming',
  },
];

export const GALLERY_ITEMS = (heroUrl: string, portraitUrl: string, wardrobeUrl: string): GalleryItem[] => [
  {
    id: 'gal-1',
    title: 'Aesthetic Consultations',
    category: 'skincare',
    imageUrl: portraitUrl,
    description: "Melanie in her classic checkered tie and vest—symbolizing her professional approach to structured skin diagnostics and unisex grooming plans.",
  },
  {
    id: 'gal-2',
    title: 'Signature Silhouette & Wardrobe Change',
    category: 'style',
    imageUrl: wardrobeUrl,
    description: "Melanie demonstrating the impact of a structured white blazer and custom grey vest—proving how tailored classics build effortless confidence.",
  },
  {
    id: 'gal-3',
    title: 'Premium Styling & Tone Analysis',
    category: 'style',
    imageUrl: roseGoldImage,
    description: "Melanie in a stunning rose-gold sequined blazer and white trousers—embodying modern luxury, high-end warmth, and confidence at every milestone.",
  },
  {
    id: 'gal-4',
    title: 'Customized Facial Treatments',
    category: 'lifestyle',
    imageUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=600',
    description: 'Premium organic facial applications using cryo-therapy, peels, and hydrating peptide serums in a peaceful setting.',
  },
  {
    id: 'gal-5',
    title: 'Flattering Make-up Sessions',
    category: 'transformation',
    imageUrl: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&q=80&w=600',
    description: 'Skillful makeup lessons emphasizing skin-glowing hydration, light-reflecting contouring, and elegant eyes.',
  },
  {
    id: 'gal-6',
    title: 'Personal Color & Silhouette Analysis',
    category: 'style',
    imageUrl: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&q=80&w=600',
    description: 'We match clothing cuts and colors with your genuine structural beauty to create a warm, authentic radiance.',
  },
];
