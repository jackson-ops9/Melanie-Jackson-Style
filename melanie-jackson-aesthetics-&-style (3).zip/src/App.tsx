import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Philosophy from './components/Philosophy';
import ProductsUsed from './components/ProductsUsed';
import Contact from './components/Contact';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';

// Import newly generated photorealistic brand assets
const heroImage = 'https://cdn.phototourl.com/free/2026-06-07-40994f83-ef7d-4186-9451-d3a2cf320a1b.png';
const portraitImage = 'https://cdn.phototourl.com/free/2026-06-07-389f437d-1177-4534-acbb-cf7eba873702.png';
import wardrobeImage from './assets/images/wardrobe_minimalist_chic_1780800761928.png';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [preselectedServiceId, setPreselectedServiceId] = useState<string | undefined>(undefined);

  const handleOpenBooking = (serviceId?: string) => {
    setPreselectedServiceId(serviceId);
    setIsBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingOpen(false);
    setPreselectedServiceId(undefined);
  };

  return (
    <div className="min-h-screen bg-ivory text-charcoal font-sans selection:bg-rose-dusty/30" id="melanie-jackson-app">
      {/* 1. Header/Navigation */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* 2. Main Content Blocks */}
      <main>
        {/* Hero Banner Section */}
        <Hero 
          onOpenBooking={() => handleOpenBooking()} 
          heroImageUrl={heroImage} 
          portraitImageUrl={portraitImage}
          wardrobeImageUrl={wardrobeImage}
        />

        {/* About Section */}
        <About 
          portraitImageUrl={portraitImage} 
          onOpenBooking={() => handleOpenBooking('skincare-consult')} 
        />

        {/* Services & Treatment Cards Section */}
        <Services onSelectService={(id) => handleOpenBooking(id)} />

        {/* Philosophy Area */}
        <Philosophy wardrobeImageUrl={wardrobeImage} />

        {/* Products Used Brand Showcase */}
        <ProductsUsed />

        {/* Contact/Inquiry forms & Direct Coordinate details */}
        <Contact onOpenBooking={() => handleOpenBooking()} />
      </main>

      {/* 3. Footer area with privacy declarations */}
      <Footer />

      {/* 4. Interactive Multistep Booking engine modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={handleCloseBooking}
        preselectedServiceId={preselectedServiceId}
      />
    </div>
  );
}
