export interface Service {
  id: string;
  name: string;
  price: number;
  duration?: string;
  category: 'skincare' | 'beauty' | 'style';
  description: string;
  squareServiceId?: string;
  squareBookingUrl?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  age: number;
  quote: string;
  category: string;
}

export interface BookingState {
  serviceId: string;
  date: string;
  timeSlot: string;
  name: string;
  email: string;
  phone: string;
  ageRange: string;
  goals: string;
  step: number;
  isConfirmed: boolean;
  bookingReference: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'skincare' | 'style' | 'transformation' | 'lifestyle';
  imageUrl: string;
  description: string;
}
